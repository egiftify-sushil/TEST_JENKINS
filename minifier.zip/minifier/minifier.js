const fs = require('fs-extra');
const path = require('path');
const terser = require('terser');
const CleanCSS = require('clean-css');

/**
 * Recursively traverse the source directory for JS, minify, and copy originals.
 * @param {string} srcDir - Source directory path for JS.
 * @param {string} destDir - Destination directory path for JS.
 */
async function minifyJsFiles(srcDir, destDir) {
  try {
    const items = await fs.readdir(srcDir, { withFileTypes: true });

    for (const item of items) {
      const srcPath = path.join(srcDir, item.name);
      const destPath = path.join(destDir, item.name);

      if (item.isDirectory()) {
        await fs.ensureDir(destPath);
        await minifyJsFiles(srcPath, destPath);
      } else if (path.extname(item.name) === '.js' && !item.name.endsWith('.min.js')) {
        try {
          const fileContent = await fs.readFile(srcPath, 'utf8');
          const minified = await terser.minify(fileContent);

          if (minified.error) {
            throw new Error(minified.error.message);
          }

          await fs.writeFile(destPath, minified.code, 'utf8');
          console.log(`Minified JS File: ${srcPath} -> ${destPath}`);
        } catch (err) {
          console.error(`Error processing JS file: ${srcPath}`);
          console.error(`Cause of failure: ${err.message || err}`);
          await fs.copy(srcPath, destPath);
          console.log(`Copied original JS file due to failure: ${srcPath} -> ${destPath}`);
        }
      } else {
        await fs.copy(srcPath, destPath);
        console.log(`Copied non-JS or already minified JS file: ${srcPath} -> ${destPath}`);
      }
    }
  } catch (err) {
    console.error(`Error reading directory: ${srcDir}`);
    console.error(err);
  }
}

/**
 * Recursively traverse the source directory for CSS, minify, and copy originals.
 * @param {string} srcDir - Source directory path for CSS.
 * @param {string} destDir - Destination directory path for CSS.
 */
async function minifyCssFiles(srcDir, destDir) {
  try {
    const items = await fs.readdir(srcDir, { withFileTypes: true });

    for (const item of items) {
      const srcPath = path.join(srcDir, item.name);
      const destPath = path.join(destDir, item.name);

      if (item.isDirectory()) {
        await fs.ensureDir(destPath);
        await minifyCssFiles(srcPath, destPath);
      } else if (path.extname(item.name) === '.css' && !item.name.endsWith('.min.css')) {
        try {
          const fileContent = await fs.readFile(srcPath, 'utf8');
          const minified = new CleanCSS().minify(fileContent);

          if (minified.errors.length) {
            throw new Error(minified.errors.join(', '));
          }

          await fs.writeFile(destPath, minified.styles, 'utf8');
          console.log(`Minified CSS File: ${srcPath} -> ${destPath}`);
        } catch (err) {
          console.error(`Error processing CSS file: ${srcPath}`);
          console.error(`Cause of failure: ${err.message || err}`);
          await fs.copy(srcPath, destPath);
          console.log(`Copied original CSS file due to failure: ${srcPath} -> ${destPath}`);
        }
      } else {
        await fs.copy(srcPath, destPath);
        console.log(`Copied non-CSS or already minified CSS file: ${srcPath} -> ${destPath}`);
      }
    }
  } catch (err) {
    console.error(`Error reading directory: ${srcDir}`);
    console.error(err);
  }
}

/**
 * Main function to execute the minifier utility.
 */
async function main() {
  // Define source and destination directories for JS and CSS
  const jsSrcDirectory = path.resolve(__dirname, '../html/js'); 
  const cssSrcDirectory = path.resolve(__dirname, '../html/css'); 
  const destDirectoryjs = path.resolve(__dirname, '../assets/js');
  const destDirectorycss = path.resolve(__dirname, '../assets/css');

  // Ensure the destination directories exist
  await fs.ensureDir(destDirectoryjs);
  await fs.ensureDir(destDirectorycss);

  // Minify JS and CSS
  await minifyJsFiles(jsSrcDirectory, destDirectoryjs);
  await minifyCssFiles(cssSrcDirectory, destDirectorycss);

  console.log('Minification process completed.');
}

main();
